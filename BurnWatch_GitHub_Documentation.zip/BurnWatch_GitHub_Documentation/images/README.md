# Project Images

Store project-generated figures and screenshots here.

Suggested filenames:
- `study_area.png`
- `sentinel2_before.png`
- `sentinel2_after.png`
- `firms_detection_map.png`
- `hourly_detection_chart.png`
- `daily_detection_chart.png`
- `ranked_fire_cells.png`
- `candidate_location_comparison.png`
- `matlab_execution_output.png`
- `system_workflow.png`

Use images generated from the actual project data. Add a caption in the report stating the source, date, bands/visualisation and processing steps. Do not use illustrative internet images as if they were project results.
