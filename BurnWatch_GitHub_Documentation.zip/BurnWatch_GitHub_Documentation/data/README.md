# Data Folder

Place input data required by the MATLAB scripts here.

Suggested layout:

```text
data/
├── README.md
└── firms/
    ├── firms.csv
    └── old/
        ├── hourly.csv
        ├── top10_cells.csv
        ├── points.csv
        └── firms_window.csv
```

The `old/` files are optional and are used only by the CSV comparison script.

## Data handling
- Keep original downloads unchanged.
- Record source, product, sensor, download date and filters in `docs/DATA_SOURCES.md`.
- Do not commit API keys, tokens or credentials.
- Do not upload large raw satellite product folders.
- If the original dataset is too large or has redistribution restrictions, provide a source link and a small permitted sample instead.
- The sample file must be clearly labelled as a sample and must not be presented as the complete dataset.
