# Team Contributions

Replace the placeholders below with the final team details. Do not assign work to a member unless the member actually performed or reviewed it.

| Team member | Role / contribution |
|---|---|
| [Name 1] | [Project coordination / research / data collection / implementation] |
| [Name 2] | [MATLAB preprocessing / FIRMS analysis / validation] |
| [Name 3] | [Sentinel-2 processing / image analysis / visualisation] |
| [Name 4] | [Documentation / testing / presentation] |

## Shared responsibilities
- Defining the problem and project objectives.
- Reviewing data sources and project assumptions.
- Discussing results and limitations.
- Preparing the final report and presentation.

## Acknowledgements
Add the names of faculty guides, mentors, institutions or collaborators only after confirming the correct spelling and preferred acknowledgement wording.
