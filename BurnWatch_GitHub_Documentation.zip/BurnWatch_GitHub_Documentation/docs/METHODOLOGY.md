# BurnWatch Methodology

## 1. Aim

The methodology compares satellite fire-detection records with optical satellite imagery to investigate candidate agricultural burning locations that may not have a corresponding FIRMS detection.

## 2. Study area

The current MATLAB script uses a working bounding box around the selected Sangrur study area:

- Latitude: 30.16 to 30.34 degrees north
- Longitude: 75.74 to 75.94 degrees east

Confirm the final boundary and document the source used to define it. A rectangular bounding box is not necessarily identical to the administrative boundary of Sangrur district.

## 3. Data inputs

### 3.1 NASA FIRMS

FIRMS provides satellite-derived active-fire/hotspot observations. Keep the original downloaded CSV unchanged. Record the sensor/product, download date, selected dates and filters.

Fields used by the current MATLAB preparation script include:
- `latitude`
- `longitude`
- `acq_date`
- `acq_time`
- `confidence`
- `satellite`
- `daynight`
- `frp`

The exact fields and formats depend on the selected FIRMS product. Inspect the downloaded CSV before running the script.

### 3.2 Sentinel-2

Sentinel-2 imagery is used to inspect surface changes around candidate locations. The project has previously considered:
- B04, B03, B02 for true-colour visualisation;
- B08 (near-infrared) for vegetation information;
- B12 (short-wave infrared) for burn-scar investigation;
- SCL (Scene Classification Layer) for scene-quality classes.

Native resolutions differ: B08 is 10 m, while B12 and SCL are 20 m. Resampling or alignment is required before pixel-by-pixel calculations. Use the raster's actual georeferencing rather than assuming a fixed tile origin.

The previously selected acquisitions were reported as:
- Before: 20 October 2025, tile 43REP.
- After: 19 November 2025, tile 43REP.

These are provisional project selections, not a guarantee that both images fully cover the same study area. The later image was reported to have substantial NoData/coverage gaps. Recheck coverage and quality before using it for conclusions.

## 4. FIRMS preprocessing

The current `p3_firms_prepare.m` workflow:
1. Reads the FIRMS CSV.
2. Parses acquisition dates.
3. Filters detections by the study-area bounding box.
4. Filters detections to the selected date range.
5. Optionally removes low-confidence records.
6. Converts acquisition time from UTC to IST by adding 5 hours 30 minutes.
7. Projects coordinates using EPSG:32643.
8. Assigns detections to 5 km grid cells.
9. Exports cleaned detections and summary tables.

### Important time note

FIRMS acquisition time is generally represented in UTC in the source data. Confirm the selected product's documentation. The script converts it to IST for analysis. The conversion wraps correctly across midnight using a 24-hour modulo operation.

## 5. Spatial aggregation

The script creates 5 km grid cells and counts detections in each cell. It also sums Fire Radiative Power (FRP), where the field is present and valid.

The ranking is a ranking of FIRMS detections, not a ranking of unmatched burn scars. A grid cell with many detections is a hotspot in the selected FIRMS data; a grid cell with no detections is not automatically a missed-fire location.

For comparisons across different runs, use a fixed grid origin, cell size, coordinate reference system, date range and filtering rules. A grid whose origin is calculated from the minimum coordinate of each filtered dataset can shift between runs.

## 6. Mapping FIRMS points to Sentinel-2 pixels

The `p2_firms_image_targets.m` workflow projects FIRMS coordinates and calculates candidate row/column positions and a local pixel window.

The current example script assumes:
- EPSG:32643;
- 20 m pixels;
- a 5490 × 5490 raster;
- fixed tile origin values.

**These are assumptions that must be verified against the actual GeoTIFF metadata.** Use MATLAB `readgeoraster` and the raster reference object, or another geospatially correct method, to derive pixel positions. Do not rely on hard-coded origin/resolution values unless they match the exact raster being analysed.

The 20 m grid is appropriate for a 20 m raster such as B12/SCL, not for the 10 m B08 raster.

## 7. Before-and-after image analysis

For each candidate:
1. Select an image before the suspected event.
2. Select an image after the suspected event.
3. Confirm both images cover the candidate location.
4. Check clouds, cloud shadows, NoData and other invalid pixels.
5. Align the images to a common CRS, pixel size and grid.
6. Inspect true-colour and suitable false-colour/SWIR composites.
7. If using spectral indices, document the formula, bands, scale factors, thresholds and validation method.
8. Save a small map or crop showing the candidate and surrounding context.

Do not interpret black/no-data regions as burned land. Do not treat every non-zero SCL value as clear land; SCL contains multiple scene classes, including cloud and shadow classes.

## 8. Candidate unmatched-location logic

A candidate unmatched burning location should only be recorded after:
- there is independent evidence suggesting burning;
- the relevant location and time window are defined;
- FIRMS data for the same sensor/product and time period have been searched;
- no corresponding FIRMS detection is found within a documented spatial and temporal tolerance;
- image coverage and quality are adequate.

Record the spatial tolerance and time tolerance explicitly. Do not choose thresholds after seeing the desired outcome without documenting that choice.

Suggested review labels:
- `Candidate` — evidence requires review.
- `Supported` — multiple evidence sources support burning.
- `Uncertain` — image or temporal evidence is insufficient.
- `Rejected` — evidence indicates no burn or another explanation.

These are project review labels, not official fire classifications.

## 9. Validation and limitations

Where possible, compare candidates with independent sources such as field observations, verified reports, additional satellite products or higher-resolution imagery. Note that FIRMS and Sentinel-2 have different sensors, resolutions and acquisition schedules.

A candidate may be absent from FIRMS because the fire was too small, too brief, obscured, outside the sensor's observation time, or because of differences in product processing. A visible dark patch may also have causes other than burning.

## 10. Reproducibility checklist

- [ ] Final boundary and coordinate system recorded.
- [ ] FIRMS product, sensor and download date recorded.
- [ ] Date window and confidence filter recorded.
- [ ] FIRMS CSV schema checked.
- [ ] Grid origin and cell size fixed for comparisons.
- [ ] Sentinel-2 product IDs and acquisition dates recorded.
- [ ] Image coverage and cloud/shadow quality checked.
- [ ] Raster georeferencing verified for every band.
- [ ] Candidate matching tolerances documented.
- [ ] Results independently reviewed.
