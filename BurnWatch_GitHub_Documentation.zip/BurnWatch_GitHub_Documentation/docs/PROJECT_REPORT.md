# BurnWatch Project Report

## Title
**BurnWatch: Finding the Farm Fires Satellites Miss**

## Abstract
BurnWatch is a satellite-data analysis project designed to investigate agricultural burning patterns and potential gaps in satellite fire detection in Sangrur, Punjab, India. The project uses NASA FIRMS fire observations and Sentinel-2 satellite imagery. MATLAB is used to filter and analyse fire-detection records, convert geographic coordinates, aggregate detections spatially and temporally, and prepare candidate locations for image inspection. Selected before-and-after satellite observations are examined to investigate possible burning evidence that does not have a corresponding FIRMS detection. The project treats such locations as candidates requiring validation rather than confirmed missed fires.

## 1. Introduction
Crop-residue burning is a seasonal agricultural practice that can contribute to air pollution. Satellite-based fire products help monitor active-fire observations over large areas. However, satellite observations are periodic and have sensor-specific detection limits. This project explores how combining active-fire records with optical satellite imagery can provide additional context for reviewing possible burning locations.

## 2. Problem statement
Some agricultural burning events may not have a corresponding record in a selected satellite active-fire dataset. The project investigates whether satellite imagery can help identify and review candidate locations that may be absent from the selected FIRMS records.

## 3. Objectives
1. Prepare FIRMS fire-detection data for the selected study area and date range.
2. Analyse temporal patterns in the retained detections.
3. Identify spatial clusters of FIRMS detections.
4. Map detection coordinates to Sentinel-2 image locations.
5. Compare selected satellite images before and after candidate events.
6. Develop a documented process for reviewing potential unmatched burning locations.

## 4. Study area
The project focuses on a selected area in Sangrur district, Punjab, India. The current working bounding box in the MATLAB script is latitude 30.16°–30.34° N and longitude 75.74°–75.94° E. Replace this description if the final boundary differs, and include a study-area map.

## 5. Data sources
### 5.1 NASA FIRMS
Describe the exact product, sensor, date range, download date, confidence filtering and relevant fields used. Add the product documentation reference.

### 5.2 Sentinel-2
Describe the exact product IDs, tile, acquisition dates, processing level, bands, spatial resolution and cloud/NoData assessment. Add before-and-after figures.

## 6. Tools and technologies
- MATLAB
- NASA FIRMS data
- Copernicus Sentinel-2 imagery
- Geographic coordinate conversion and spatial analysis
- CSV processing and visualisation

## 7. Methodology
Explain the workflow in `METHODOLOGY.md`. Include a workflow diagram and the actual parameters used in the final run.

## 8. Implementation
Describe each script:
- `p3_firms_prepare.m`: FIRMS preprocessing and summary outputs.
- `p3_check_csvs.m`: comparison of selected old and new CSV outputs.
- `p2_firms_image_targets.m`: mapping FIRMS points to image-pixel windows, subject to raster-georeferencing verification.
- [Add other scripts actually used.]

## 9. Results
**Insert actual results only. Do not invent values.**

Recommended subsections:
- Number of raw FIRMS records: [value]
- Number of records retained after filtering: [value]
- Date-wise detection pattern: [insert graph/table]
- Hour-wise detection pattern in IST: [insert graph/table]
- Top detection grid cells: [insert table/map]
- Number of FIRMS points inside the selected raster: [value]
- Number of candidate unmatched locations: [value, only after applying and documenting the matching/validation method]
- Sentinel-2 image coverage and quality: [measured result]

For every figure, provide its date, source and processing description.

## 10. Discussion
Discuss what the data shows, what it does not show, possible reasons for missing detections, the impact of image coverage and cloud/shadow conditions, and any uncertainty in the matching method.

## 11. Limitations
Discuss sensor resolution, revisit/observation timing, fire duration and intensity, cloud cover, image NoData, geolocation uncertainty, matching thresholds and the possibility of confusing burn scars with other land changes.

## 12. Conclusion
Summarise the implemented workflow and the evidence obtained. State whether the project identified candidate locations for further review. Do not claim that the system detects all missed fires unless this has been rigorously validated.

## 13. Future scope
- Validated burn-scar index analysis.
- Additional satellite products and dates.
- Machine-learning classification with labelled samples.
- Automated map dashboard and alerting.
- Field or independent-data validation.
- Expansion to other districts.

## References
1. NASA FIRMS — https://firms.modaps.eosdis.nasa.gov/
2. Copernicus Data Space Ecosystem — https://dataspace.copernicus.eu/
3. ESA Sentinel-2 mission — https://www.esa.int/Applications/Observing_the_Earth/Copernicus/Sentinel-2
4. [Add papers and reports actually consulted, with author, title, year and URL/DOI.]

## Appendix
Add script descriptions, parameter tables, sample CSV headers and supplementary figures.
