# BurnWatch Data Sources and Data Dictionary

## 1. NASA FIRMS

Website: https://firms.modaps.eosdis.nasa.gov/

Purpose: Active-fire/hotspot observations used to study the timing and spatial distribution of detected fire activity.

For the final project record, fill in:
- Product name: [e.g., VIIRS 375 m / MODIS]
- Satellite/platform: [exact platform from downloaded product]
- Download date: [YYYY-MM-DD]
- Acquisition date range: [start to end]
- Geographic filter: [final bounds or boundary]
- Confidence filter: [all / nominal and high / other]
- Source file name: [exact original file name]
- Product documentation URL: [link to the relevant product documentation]

Do not write “VIIRS 375 m” unless that is the actual product selected in the downloaded file.

### FIRMS field descriptions

| Field | Meaning |
|---|---|
| latitude | Latitude of the reported detection |
| longitude | Longitude of the reported detection |
| acq_date | Acquisition date reported by the product |
| acq_time | Acquisition time, commonly encoded as HHMM |
| confidence | Product-specific confidence indicator |
| satellite | Satellite/platform identifier |
| daynight | Day/night observation indicator |
| frp | Fire Radiative Power, where supplied by the product |

Field availability and definitions vary by product. Use the official product documentation for the selected dataset.

## 2. Copernicus Sentinel-2

Website: https://dataspace.copernicus.eu/

Purpose: Optical satellite imagery used to inspect land-surface conditions before and after candidate burning events.

Record the exact product metadata:
- Product ID: [paste full Sentinel-2 product identifier]
- Tile: [e.g., 43REP, verify from metadata]
- Acquisition date/time: [UTC timestamp]
- Processing level: [e.g., L1C or L2A]
- Cloud cover metadata: [reported value]
- Download date: [YYYY-MM-DD]
- Bands used: [list]
- CRS and pixel size: [read from raster metadata]

### Bands considered

| Band/layer | Description | Native pixel size |
|---|---|---:|
| B02 | Blue | 10 m |
| B03 | Green | 10 m |
| B04 | Red | 10 m |
| B08 | Near infrared | 10 m |
| B12 | SWIR 2 | 20 m |
| SCL | Scene Classification Layer (L2A) | 20 m |

Check the product documentation and metadata for the specific product version. B08 and B12 do not have the same native resolution.

## 3. Project working date selections

Previously considered Sentinel-2 acquisitions:
- Before image: 20 October 2025, tile 43REP.
- After image: 19 November 2025, tile 43REP.

The after image was reported to contain substantial NoData/coverage gaps. These dates must be revalidated before being described as the final image pair.

## 4. Data handling

- Preserve original downloaded files separately from processed outputs.
- Do not upload access tokens, API keys or private credentials.
- Do not upload entire large `.SAFE` product folders to GitHub.
- Provide source links and product identifiers so others can obtain the original data.
- Upload only small sample datasets when licensing and file size permit.
- Clearly identify sample, synthetic, filtered and final datasets.

## 5. Output CSV data dictionary

### `firms_clean.csv`
Expected fields from the current script:
- `latitude`
- `longitude`
- `date`
- `acq_time`
- `hour_ist`
- `satellite`
- `confidence`
- `frp`
- `cell_id`

### `points.csv`
- `lat`
- `lon`
- `date`
- `hour_ist`
- `confidence`

### `hourly.csv`
- `hour_ist` — hour of day in IST (0–23).
- `count` — number of retained detections assigned to that hour.

### `fires_by_date.csv`
- `date` — date of detection.
- `count` — number of retained detections on that date.
- `cumulative_share` — cumulative fraction of retained detections through that date.

### `fire_cells_ranked.csv`
- `cell_id` — grid-cell identifier.
- `detection_count` — number of retained detections in the cell.
- `total_frp` — sum of FRP values in the cell.
- `rank` — descending rank by detection count.

### `firms_image_targets.csv`
- `lat`, `lon`, `date`, `hour_ist`, `cell_id`
- `tile_col`, `tile_row`
- `row_min`, `row_max`, `col_min`, `col_max`

The pixel coordinates are valid only if the script's CRS, raster origin, pixel size and dimensions match the actual image being used.
