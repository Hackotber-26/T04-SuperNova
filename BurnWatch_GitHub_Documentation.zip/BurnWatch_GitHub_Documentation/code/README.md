# MATLAB Code

This folder contains the MATLAB scripts used in the BurnWatch workflow.

## Current scripts

| Script | Purpose | Input | Output |
|---|---|---|---|
| `p3_firms_prepare.m` | Filters FIRMS data and creates summary tables | `data/firms/firms.csv` | `results/*.csv` |
| `p3_check_csvs.m` | Compares selected old and new CSV summaries | `data/firms/old/*.csv`, `results/*.csv` | Command-window comparison |
| `p2_firms_image_targets.m` | Converts fire coordinates to image-pixel windows | `results/firms_clean.csv` | `results/firms_image_targets.csv` |

## Run order

1. Put the original FIRMS CSV at the input path expected by `p3_firms_prepare.m`.
2. Check its column names and date/time formats.
3. Run `p3_firms_prepare.m`.
4. Check the generated files in `results/`.
5. Run `p2_firms_image_targets.m` only after verifying the raster CRS, origin, resolution and dimensions used by that script.
6. Run `p3_check_csvs.m` only if the referenced old CSV files are present.

## Requirements and assumptions

- MATLAB.
- Mapping Toolbox is required for functions such as `projcrs` and `projfwd`.
- The input CSV must contain the expected fields.
- Date parsing must match the actual source CSV format.
- The coordinate reference system must be appropriate for the study area.
- Hard-coded raster origin and dimensions in the image-target script must be checked against the exact GeoTIFF metadata before use.

## Important

The scripts are provided for research/educational use. A successful script run confirms that the code executed; it does not independently validate the scientific correctness of the input data, georeferencing or conclusions.
