# BurnWatch: Finding the Farm Fires Satellites Miss

> A satellite-data analysis project investigating agricultural burning patterns and potentially missed fire detections in Sangrur, Punjab, India.

## 1. Project overview

BurnWatch investigates whether agricultural burning locations may be absent from available satellite fire-detection records. It combines fire-hotspot observations from NASA FIRMS with Sentinel-2 satellite imagery and MATLAB-based spatial and temporal analysis.

The project is designed to help identify locations that deserve further investigation. A location without a FIRMS detection is **not automatically a confirmed missed fire**. Evidence from imagery, acquisition dates, image coverage and other sources must be checked before classifying a location as a suspected unmatched burning location.

## 2. Problem statement

Agricultural residue burning is a seasonal concern in parts of northern India. Satellite fire products provide valuable observations, but individual events may not appear in a fire-detection dataset because of observation timing, fire duration, fire size, cloud conditions, sensor resolution or other detection limitations.

BurnWatch studies these limitations in a selected area of Sangrur district, Punjab, by comparing FIRMS detections with Sentinel-2 imagery.

## 3. Objectives

- Collect and prepare satellite fire-detection records for the study area.
- Analyse the spatial and temporal distribution of FIRMS detections.
- Map fire-detection coordinates to the relevant satellite-image grid.
- Compare selected Sentinel-2 observations before and after suspected burning events.
- Investigate candidate locations where image evidence may exist without a corresponding FIRMS record.
- Present the analysis through maps, tables, figures and reproducible MATLAB scripts.

## 4. Study area and analysis settings

The current MATLAB preparation script uses the following working settings. Confirm these against the final study design before publishing results.

| Parameter | Current working value |
|---|---|
| Study area | Sangrur, Punjab, India |
| Latitude | 30.16° to 30.34° N |
| Longitude | 75.74° to 75.94° E |
| FIRMS date window | 25 October 2025 to 6 November 2025 |
| FIRMS confidence filter | Low-confidence records excluded |
| Spatial grid | 5 km cells |
| Projected CRS used in scripts | WGS 84 / UTM zone 43N (EPSG:32643) |

**Consistency note:** Earlier project scripts used a wider longitude range (75.73°–75.95°) and a different date window (21 October–20 November 2025). Do not combine their outputs with the current outputs unless the same bounds, dates, confidence filter and grid definition are used.

## 5. Data sources

- **NASA FIRMS:** https://firms.modaps.eosdis.nasa.gov/
- **Copernicus Data Space Ecosystem:** https://dataspace.copernicus.eu/
- **Sentinel-2 mission information:** https://www.esa.int/Applications/Observing_the_Earth/Copernicus/Sentinel-2

Record the exact FIRMS product/sensor, download date, Sentinel-2 product identifiers, acquisition dates, processing level and selected bands in `docs/DATA_SOURCES.md`.

## 6. Technologies

- MATLAB for data preparation, coordinate conversion, analysis and visualisation.
- NASA FIRMS fire detections for hotspot observations.
- Sentinel-2 imagery for visual and spectral investigation of land-surface changes.
- CSV files for input, intermediate and output tables.
- GIS coordinate systems for spatial processing.

## 7. Workflow

1. Download FIRMS detections for the study area and selected dates.
2. Save the original downloaded file separately and retain its source metadata.
3. Read the FIRMS CSV in MATLAB and filter records by coordinates, dates and confidence.
4. Convert acquisition time from UTC to Indian Standard Time (IST), where applicable.
5. Project fire coordinates into the selected map coordinate reference system.
6. Aggregate detections into spatial grid cells and calculate summary statistics.
7. Convert selected fire coordinates into image pixel locations using the actual georeferencing of the Sentinel-2 raster.
8. Inspect Sentinel-2 imagery from before and after candidate events.
9. Check image coverage, cloud/shadow contamination and data quality.
10. Compare image evidence with FIRMS records and classify candidates conservatively.
11. Export tables, maps and figures for review.

## 8. Repository structure

```text
BurnWatch-Farm-Fire-Detection/
├── README.md
├── LICENSE
├── .gitignore
├── code/
│   ├── README.md
│   ├── p3_firms_prepare.m
│   ├── p3_check_csvs.m
│   └── p2_firms_image_targets.m
├── data/
│   ├── README.md
│   └── sample_firms.csv
├── results/
│   └── README.md
├── images/
│   └── README.md
└── docs/
    ├── PROJECT_REPORT.md
    ├── METHODOLOGY.md
    ├── DATA_SOURCES.md
    └── CONTRIBUTIONS.md
```

Only add files that actually exist and have been checked. Do not create empty or fabricated result files.

## 9. Key outputs

Depending on which scripts have been run successfully, the project may generate:

- `firms_clean.csv` — filtered FIRMS records.
- `points.csv` — fire coordinates and selected attributes.
- `hourly.csv` — detection counts grouped by hour in IST.
- `fires_by_date.csv` — detection counts by date.
- `fire_cells_ranked.csv` — grid cells ranked by FIRMS detection count and total FRP.
- `firms_image_targets.csv` — fire locations and corresponding image-pixel windows.

These outputs describe FIRMS detections and spatial processing. They do not, by themselves, prove that an unmatched fire occurred.

## 10. Meaning of an unmatched burning location

An **unmatched burning location** is a candidate location where independent evidence suggests burning may have occurred, but no corresponding detection is found in the selected FIRMS dataset within the defined spatial and temporal matching rules.

For every candidate, document:
- evidence of burning (for example, a visible burn scar or a verified report);
- image acquisition date and time;
- FIRMS search date range and sensor/product;
- spatial matching distance or area;
- image coverage and cloud/shadow quality;
- reason for treating it as a candidate;
- confidence or review status.

A missing FIRMS point alone is insufficient evidence to label a location as a missed fire.

## 11. Limitations

- FIRMS hotspots are satellite observations, not exact field boundaries or guaranteed fire-start locations.
- A FIRMS detection time is an observation time, not necessarily the exact time burning began.
- Small, short-lived or obscured fires may not be detected.
- Sentinel-2 images are acquired on particular dates; they do not provide continuous observation.
- Clouds, cloud shadows, haze, crop/soil variation and image gaps can affect interpretation.
- A burn scar can be confused with other land-surface changes without careful validation.
- Spatial and temporal matching thresholds influence the number of candidate unmatched locations.

## 12. Future scope

- Add validated burn-scar indices and classification methods.
- Compare multiple satellite sensors and observation dates.
- Develop a map-based dashboard for candidate review.
- Add automated notifications after validation.
- Explore machine-learning classification using labelled, quality-controlled samples.
- Extend the method to additional agricultural regions.

## 13. Reproducibility

Before running the scripts:
1. Install MATLAB and check the required toolboxes.
2. Place the FIRMS input CSV in the path specified by the script.
3. Confirm the CSV column names and date/time formats.
4. Verify the coordinate reference system and raster georeferencing.
5. Use consistent study-area bounds, date windows and grid definitions.
6. Run scripts in the documented order.

See `docs/METHODOLOGY.md` and `code/README.md`.

## 14. Team

Add the final approved team-member names, roles and affiliations in `docs/CONTRIBUTIONS.md`.

## 15. Project status

Update this section honestly, for example:
- Data collection: [Not started / In progress / Completed]
- FIRMS preprocessing: [Not started / In progress / Completed]
- Sentinel-2 comparison: [Not started / In progress / Completed]
- Candidate validation: [Not started / In progress / Completed]
- Dashboard: [Not started / In progress / Completed]

## 16. Disclaimer

BurnWatch is an academic/research prototype. Candidate locations require independent validation before being described as confirmed missed fires or used for enforcement or operational decisions.
